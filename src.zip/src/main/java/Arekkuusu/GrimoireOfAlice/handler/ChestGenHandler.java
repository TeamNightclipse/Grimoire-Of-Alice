/**
 * This class was created by <Katrix>. It's distributed as
 * part of the Journey To Gensokyo Mod. Get the Source Code in github:
 * https://github.com/Katrix-/JTG
 *
 * Journey To Gensokyo is Open Source and distributed under the
 * a modifed Botania license: https://github.com/Katrix-/JTG/blob/master/LICENSE.md
 */

package Arekkuusu.GrimoireOfAlice.handler;

import Arekkuusu.GrimoireOfAlice.item.GOAItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraftforge.common.ChestGenHooks;

public class ChestGenHandler {
public static WeightedRandomChestContent enchantedbook = 
new WeightedRandomChestContent(new ItemStack
(GOAItem.EnhancedBook, 1, 0),1 ,2 ,9);

public static void init(){
	
	ChestGenHooks.getInfo(ChestGenHooks.DUNGEON_CHEST).addItem(enchantedbook);
	}
}
