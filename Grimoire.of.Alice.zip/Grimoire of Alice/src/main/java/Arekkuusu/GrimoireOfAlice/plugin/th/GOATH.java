package Arekkuusu.GrimoireOfAlice.plugin.th;

public class GOATH {

}
