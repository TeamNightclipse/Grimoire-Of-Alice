package Arekkuusu.GrimoireOfAlice.handler;

import Arekkuusu.GrimoireOfAlice.item.GOAItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraftforge.common.ChestGenHooks;

public class ChestGenHandler {
public static WeightedRandomChestContent enchantedbook = 
new WeightedRandomChestContent(new ItemStack
(GOAItem.EnhancedBook, 1, 0),1 ,2 ,9);

public static void init(){
	
	ChestGenHooks.getInfo(ChestGenHooks.DUNGEON_CHEST).addItem(enchantedbook);
	}
}
