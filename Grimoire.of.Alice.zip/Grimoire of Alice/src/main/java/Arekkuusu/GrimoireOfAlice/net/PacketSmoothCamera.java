package Arekkuusu.GrimoireOfAlice.net;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
public class PacketSmoothCamera {
	public boolean flag;

	public PacketSmoothCamera() {}

	public PacketSmoothCamera(boolean SmoothOn) {
		this.flag = SmoothOn;
	}

	
	public void toBytes(ByteBuf buf) {
		buf.writeBoolean(flag);
	}

	
	public void fromBytes(ByteBuf buf) {
		flag = buf.readBoolean();
	}
	
	public static class Handler implements IMessageHandler<PacketSmoothCamera, IMessage> {

		@Override
		public IMessage onMessage(PacketSmoothCamera message, MessageContext ctx) {
			Minecraft.getMinecraft().gameSettings.smoothCamera = message.flag;
			return null;
		}
	}
}
