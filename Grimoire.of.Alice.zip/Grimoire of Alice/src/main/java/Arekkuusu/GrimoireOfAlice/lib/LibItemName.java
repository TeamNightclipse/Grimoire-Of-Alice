package Arekkuusu.GrimoireOfAlice.lib;

public class LibItemName {

	public final static String ENHANCED_BOOK = "Enhanced Book";
}
