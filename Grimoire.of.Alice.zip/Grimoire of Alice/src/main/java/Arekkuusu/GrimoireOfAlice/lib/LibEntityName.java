package Arekkuusu.GrimoireOfAlice.lib;

public class LibEntityName {

}
