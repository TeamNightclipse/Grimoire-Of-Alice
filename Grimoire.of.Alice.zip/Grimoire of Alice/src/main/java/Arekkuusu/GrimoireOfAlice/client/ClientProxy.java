package Arekkuusu.GrimoireOfAlice.client;
import cpw.mods.fml.client.registry.RenderingRegistry;
import Arekkuusu.GrimoireOfAlice.CommonProxy;
public class ClientProxy extends CommonProxy{

}
