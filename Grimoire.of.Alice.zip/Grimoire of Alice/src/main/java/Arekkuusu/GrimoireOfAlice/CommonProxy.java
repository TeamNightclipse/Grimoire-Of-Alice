package Arekkuusu.GrimoireOfAlice;

public class CommonProxy {
	// Client stuff
		public void registerRenderers() {
			// Nothing here as the server doesn't render graphics or entities!

		}
}
