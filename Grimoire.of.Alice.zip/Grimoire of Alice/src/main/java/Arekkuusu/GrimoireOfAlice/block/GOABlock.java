package Arekkuusu.GrimoireOfAlice.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class GOABlock extends Block {

	protected GOABlock(Material material) {
		super(material);
	}

}
