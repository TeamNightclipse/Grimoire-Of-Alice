package Arekkuusu.GrimoireOfAlice.item.crafting;

import cpw.mods.fml.common.registry.GameRegistry;
import Arekkuusu.GrimoireOfAlice.block.GOABlock;
import Arekkuusu.GrimoireOfAlice.handler.ConfigHandler;
import Arekkuusu.GrimoireOfAlice.item.GOAItem;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class CraftingVanilla {
	public static void misc(){
		if (ConfigHandler.BookEnabled){
			GameRegistry.addRecipe(new ItemStack
		(GOAItem.EnhancedBook,1 ,2));
		}
	}
	
	public static void Table(){
	}
}
