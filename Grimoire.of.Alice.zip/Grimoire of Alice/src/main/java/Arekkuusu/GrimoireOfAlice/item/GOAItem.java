package Arekkuusu.GrimoireOfAlice.item;

import cpw.mods.fml.common.registry.GameRegistry;
import Arekkuusu.GrimoireOfAlice.lib.LibEntityName;
import Arekkuusu.GrimoireOfAlice.lib.LibItemName;
import Arekkuusu.GrimoireOfAlice.lib.LibMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class GOAItem extends Item {

	public static Item EnhancedBook;
	
	public static Item compEnhancedBook;
	
	public static void preInit(){
		
		EnhancedBook = new itemEnchantedBook
	().setCreativeTab(CreativeTabs.tabCombat);
		
		GameRegistry.registerItem(EnhancedBook, LibItemName.ENHANCED_BOOK);
	
		compEnhancedBook = new ItemGOABase().setTextureName(LibMod.MODID +
				":EnchantedBook").setUnlocalizedName("Enchanted Book");
	}

}
