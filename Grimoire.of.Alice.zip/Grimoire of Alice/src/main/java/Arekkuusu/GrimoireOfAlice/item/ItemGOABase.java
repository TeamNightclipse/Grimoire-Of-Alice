package Arekkuusu.GrimoireOfAlice.item;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ItemGOABase extends Item{
	
	public ItemGOABase() {
		super();
		setCreativeTab(CreativeTabs.tabMisc);
	}
}
